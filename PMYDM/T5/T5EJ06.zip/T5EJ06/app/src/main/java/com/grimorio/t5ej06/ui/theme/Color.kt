package com.grimorio.t5ej06.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val VerdeCuadrante = Color(0xFFA8F3B4) // Color verde claro aproximado
val RojoCuadrante = Color(0xFFFF6B6B)  // Color rojo claro aproximado
val AzulCuadrante = Color(0xFFB4D8FF)  // Color azul claro aproximado
val AmarilloCuadrante = Color(0xFFFFFA80) // Color amarillo claro aproximado
