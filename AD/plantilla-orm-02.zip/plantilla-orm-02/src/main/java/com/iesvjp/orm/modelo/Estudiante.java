package com.iesvjp.orm.modelo;

import java.time.LocalDate;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Entidad de ejemplo · ACADT · RA3 · CE c.
 *
 * Requisitos de una clase persistente:
 *  - Anotada con @Entity y con un atributo anotado con @Id.
 *  - Constructor sin argumentos, public o protected.
 *  - Ni la clase ni sus atributos persistentes son final.
 *  - Atributos private, con getters y setters.
 */
@Entity
@Table(name = "estudiantes")
public class Estudiante {

    // Long y no long: un id null indica que el objeto todavía no se ha guardado
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   // AUTO_INCREMENT en MySQL
    private Long id;

    @Column(nullable = false, length = 40)
    private String nombre;

    @Column(nullable = false, length = 80)
    private String apellidos;

    // java.time se guarda sin anotaciones: LocalDate -> DATE
    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;

    // Dirección habitual: sus columnas van en la tabla estudiantes
    @Embedded
    private Direccion direccion;

    // Segunda dirección del mismo tipo: hay que cambiar el nombre de sus columnas
    @Embedded
    @AttributeOverride(name = "via", column = @Column(name = "via_facturacion"))
    @AttributeOverride(name = "codigoPostal", column = @Column(name = "cp_facturacion", length = 5))
    @AttributeOverride(name = "poblacion", column = @Column(name = "poblacion_facturacion"))
    @AttributeOverride(name = "provincia", column = @Column(name = "provincia_facturacion"))
    private Direccion direccionFacturacion;

    /** Constructor vacío obligatorio para JPA. */
    protected Estudiante() {
    }

    public Estudiante(String nombre, String apellidos, LocalDate fechaNacimiento, Direccion direccion) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public Direccion getDireccionFacturacion() {
        return direccionFacturacion;
    }

    public void setDireccionFacturacion(Direccion direccionFacturacion) {
        this.direccionFacturacion = direccionFacturacion;
    }

    @Override
    public String toString() {
        return "Estudiante[id=" + id + ", " + nombre + " " + apellidos
                + ", nacido el " + fechaNacimiento + ", dirección: " + direccion
                + (direccionFacturacion != null ? ", facturación: " + direccionFacturacion : "")
                + "]";
    }
}
