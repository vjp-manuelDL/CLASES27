package com.iesvjp.orm;

import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.iesvjp.orm.modelo.Direccion;
import com.iesvjp.orm.modelo.Estudiante;
import com.iesvjp.orm.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

/**
 * Entidades, valores y ciclo de vida · ACADT · RA3 · CE c, d, e, g.
 *
 * Cada paso corresponde a un apartado de la presentación:
 *
 *  1. Guardar con persist() ........................ 4.1
 *  2. El contexto de persistencia .................. 4 (contexto de persistencia)
 *  3. Recuperar con find() ......................... 4.2
 *  4. Modificar sin update() ....................... 4.3
 *  5. Objetos separados (detached) ................. 4.4
 *  6. Volver a gestionar con merge() ............... 4.5
 *  7. Eliminar con remove() ........................ 4.6
 *  8. Transacción con rollback ..................... 4.7
 *  9. Un error frecuente ........................... 4.8
 *
 * Observa en la consola el SQL que lanza Hibernate en cada paso.
 */
public class App {

    // Referencia estática para que el ajuste de nivel de log no se pierda
    private static final Logger LOG_HIBERNATE = Logger.getLogger("org.hibernate");

    public static void main(String[] args) {
        // Oculta los mensajes INFO de arranque de Hibernate (el SQL se sigue mostrando)
        LOG_HIBERNATE.setLevel(Level.WARNING);

        try {
            Long idAna = guardar();
            contextoDePersistencia(idAna);
            recuperar();
            modificar(idAna);
            Estudiante separado = separar(idAna);
            volverAGestionar(separado);
            eliminar(idAna);
            transaccionConRollback();
            errorFrecuente();
        } finally {
            JPAUtil.cerrar();
        }
    }

    // 1. persist(): de transient a managed. Con IDENTITY, el INSERT es inmediato
    private static Long guardar() {
        titulo("1. Guardar con persist()");
        Estudiante ana = new Estudiante("Ana", "Ruiz Pérez", LocalDate.of(2005, 3, 14),
                new Direccion("C/ Mayor, 5", "06800", "Mérida", "Badajoz"));
        Estudiante luis = new Estudiante("Luis", "García Gil", LocalDate.of(2004, 11, 2),
                new Direccion("Avda. de Portugal, 20", "10001", "Cáceres", "Cáceres"));
        // Luis tiene además una dirección de facturación (columnas *_facturacion)
        luis.setDireccionFacturacion(
                new Direccion("C/ Santa Eulalia, 8", "06800", "Mérida", "Badajoz"));
        Estudiante marta = new Estudiante("Marta", "López Díaz", LocalDate.of(2005, 7, 30),
                new Direccion("C/ San Pedro, 12", "06002", "Badajoz", "Badajoz"));

        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            System.out.println("Antes de persist(), id de Ana: " + ana.getId());   // null
            tx.begin();
            em.persist(ana);
            System.out.println("Después de persist(), id de Ana: " + ana.getId()); // ya tiene valor
            em.persist(luis);
            em.persist(marta);
            tx.commit();
            System.out.println("Guardados:\n  " + ana + "\n  " + luis + "\n  " + marta);
            return ana.getId();
        } catch (RuntimeException e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw e;
        } finally {
            em.close();
        }
    }

    // 2. Dentro de un mismo EntityManager, el mismo id devuelve el mismo objeto
    private static void contextoDePersistencia(Long id) {
        titulo("2. El contexto de persistencia");
        EntityManager em = JPAUtil.getEntityManager();
        try {
            Estudiante a = em.find(Estudiante.class, id);   // SELECT
            Estudiante b = em.find(Estudiante.class, id);   // sin SELECT: ya está en el contexto
            System.out.println("¿a == b? " + (a == b));     // true
        } finally {
            em.close();
        }
    }

    // 3. find() devuelve null si no existe el id
    private static void recuperar() {
        titulo("3. Recuperar con find()");
        EntityManager em = JPAUtil.getEntityManager();
        try {
            Estudiante e = em.find(Estudiante.class, 999L);
            if (e == null) {
                System.out.println("No existe el estudiante 999");
            }
        } finally {
            em.close();
        }
    }

    // 4. Un objeto managed se guarda solo al confirmar: no hay update() (dirty checking)
    private static void modificar(Long id) {
        titulo("4. Modificar sin update()");
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            Estudiante e = em.find(Estudiante.class, id);   // managed
            e.setNombre("Ana María");                       // solo se cambia el objeto
            tx.commit();                                    // UPDATE automático
            System.out.println("Modificado: " + e);
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    // 5. Al cerrar el EntityManager, el objeto pasa a detached y sus cambios no se guardan
    private static Estudiante separar(Long id) {
        titulo("5. Objetos separados (detached)");
        EntityManager em = JPAUtil.getEntityManager();
        Estudiante e = em.find(Estudiante.class, id);
        System.out.println("¿Está gestionado? " + em.contains(e));   // true
        em.close();                                                 // e pasa a detached

        e.setApellidos("Ruiz Martín");                              // no se guardará
        System.out.println("Apellidos en memoria: " + e.getApellidos());
        System.out.println("Apellidos en la base de datos: " + buscar(id).getApellidos());
        return e;
    }

    // 6. merge() copia el estado del objeto detached en uno managed y devuelve este último
    private static void volverAGestionar(Estudiante separado) {
        titulo("6. Volver a gestionar con merge()");
        EntityManager em2 = JPAUtil.getEntityManager();
        EntityTransaction tx = em2.getTransaction();
        try {
            tx.begin();
            Estudiante gestionado = em2.merge(separado);    // SELECT y UPDATE
            tx.commit();
            System.out.println("¿Es el mismo objeto? " + (gestionado == separado));   // false
            System.out.println("Apellidos en la base de datos: "
                    + buscar(separado.getId()).getApellidos());
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        } finally {
            em2.close();
        }
    }

    // 7. remove() solo admite objetos managed: primero find() y después remove()
    private static void eliminar(Long id) {
        titulo("7. Eliminar con remove()");
        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            Estudiante e = em.find(Estudiante.class, id);
            if (e != null) {
                em.remove(e);       // removed
            }
            tx.commit();            // DELETE
            System.out.println("¿Sigue existiendo? " + (buscar(id) != null));   // false
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    // 8. Si algo falla, rollback() deshace toda la transacción (pero no los objetos en memoria)
    private static void transaccionConRollback() {
        titulo("8. Transacción con rollback");
        Estudiante lucia = new Estudiante("Lucía", "Sanz Mora", LocalDate.of(2006, 1, 20),
                new Direccion("C/ Ancha, 3", "10600", "Plasencia", "Cáceres"));
        Estudiante sinNombre = new Estudiante(null, "Sin Nombre", LocalDate.of(2006, 5, 5),
                new Direccion("C/ Nueva, 1", "06300", "Zafra", "Badajoz"));

        EntityManager em = JPAUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(lucia);          // INSERT: Lucía recibe su id
            em.persist(sinNombre);      // error: el nombre es obligatorio
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            System.out.println("Operación cancelada: " + ex.getClass().getSimpleName());
        } finally {
            em.close();
        }
        System.out.println("Id de Lucía en memoria: " + lucia.getId());
        System.out.println("¿Existe Lucía en la base de datos? "
                + (lucia.getId() != null && buscar(lucia.getId()) != null));   // false
    }

    // 9. persist() con un objeto que ya tiene id: "detached entity passed to persist"
    private static void errorFrecuente() {
        titulo("9. Un error frecuente");
        EntityManager em = JPAUtil.getEntityManager();
        Estudiante luis = em.find(Estudiante.class, 2L);
        em.close();                                 // luis pasa a detached

        EntityManager em2 = JPAUtil.getEntityManager();
        EntityTransaction tx = em2.getTransaction();
        try {
            tx.begin();
            em2.persist(luis);                      // error: para objetos detached se usa merge()
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            System.out.println("Error esperado: " + ex.getMessage());
        } finally {
            em2.close();
        }
    }

    // ---------- Métodos auxiliares ----------

    private static Estudiante buscar(Long id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.find(Estudiante.class, id);
        } finally {
            em.close();
        }
    }

    private static void titulo(String texto) {
        System.out.println("\n===== " + texto + " =====");
    }
}
