# Plantilla ORM 02 · Entidades, valores y ciclo de vida

**Módulo:** 0486 Acceso a datos · **RA3** · CE c, d, e, g
**Presentación:** UT4 · 02 Entidades, valores y ciclo de vida

Ejemplos de la presentación sobre una entidad `Estudiante` con fecha de nacimiento y dos direcciones embebidas. `App` recorre las operaciones del `EntityManager` y los estados de una entidad, en el mismo orden que la presentación.

## Puesta en marcha

Igual que la plantilla 01:

1. Importar como proyecto Maven. En Eclipse: *File → Import → Maven → Existing Maven Projects*.
2. Poner en `src/main/resources/jpa.properties` la URL, el usuario y la contraseña de vuestro MySQL.
3. Ejecutar `App.java` como aplicación Java.

## Estructura

```
src/main/resources/
    jpa.properties                        Conexión y propiedades de Hibernate
src/main/java/com/iesvjp/orm/
    modelo/Estudiante.java                Entidad: clave, java.time, @Embedded y @AttributeOverride
    modelo/Direccion.java                 Tipo embebido (@Embeddable)
    util/JPAUtil.java                     Unidad de persistencia: registra Estudiante y Direccion
    App.java                              Operaciones y ciclo de vida, paso a paso
```

## La tabla `estudiantes`

`Direccion` no tiene tabla propia: sus columnas se añaden a `estudiantes`. La segunda dirección usa `@AttributeOverride` para cambiar el nombre de sus columnas.

| Columnas | Proceden de |
| --- | --- |
| `id`, `nombre`, `apellidos`, `fecha_nacimiento` | `Estudiante` |
| `via`, `codigoPostal`, `poblacion`, `provincia` | `direccion` (habitual) |
| `via_facturacion`, `cp_facturacion`, `poblacion_facturacion`, `provincia_facturacion` | `direccionFacturacion` |

## Qué hace `App.java`

| Paso | Operación | Apartado | Qué observar |
| --- | --- | --- | --- |
| 1 | Guardar tres estudiantes con `persist()` | 4.1 | El id ya tiene valor justo después de `persist()` |
| 2 | Dos `find()` del mismo id | Contexto de persistencia | Una sola SELECT y `a == b` es `true` |
| 3 | `find()` de un id que no existe | 4.2 | Devuelve `null` |
| 4 | Cambiar el nombre con un *setter* | 4.3 | UPDATE al confirmar, sin llamar a ningún método |
| 5 | Cerrar el `EntityManager` y cambiar los apellidos | 4.4 | El cambio no llega a la base de datos |
| 6 | `merge()` del objeto anterior | 4.5 | Ahora sí se guarda, y `merge()` devuelve otro objeto |
| 7 | `remove()` | 4.6 | DELETE al confirmar |
| 8 | Transacción con un estudiante sin nombre | 4.7 | Se deshace todo, aunque Lucía conserva su id en memoria |
| 9 | `persist()` de un objeto *detached* | 4.8 | Error "detached entity passed to persist" |

Al terminar, la tabla contiene a Luis y a Marta.
